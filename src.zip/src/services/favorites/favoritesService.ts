import type { SupabaseClient } from "@supabase/supabase-js";
import { createClient } from "@/services/supabase/client";
import { getUnifiedPlace, type UnifiedPlace } from "@/services/places/unifiedPlaceService";
import { recomputeTravelDna } from "@/services/travelDna/travelDnaService";

export type FavoriteStatus = "liked" | "saved" | "skipped";
export type PlaceType = "place" | "destination";

export async function getFavoriteStatus(
  supabase: SupabaseClient,
  userId: string,
  placeId: string
): Promise<FavoriteStatus | null> {
  const { data } = await supabase
    .from("favorites")
    .select("status")
    .eq("user_id", userId)
    .eq("place_id", placeId)
    .maybeSingle();
  return (data?.status as FavoriteStatus | undefined) ?? null;
}

/** מפעיל/מבטל לייק או שמירה. לחיצה על אותה פעולה שכבר פעילה מבטלת אותה. */
export async function toggleFavorite(
  supabase: SupabaseClient,
  userId: string,
  placeId: string,
  placeType: PlaceType,
  action: "liked" | "saved"
): Promise<FavoriteStatus | null> {
  const current = await getFavoriteStatus(supabase, userId, placeId);

  if (current === action) {
    await supabase.from("favorites").delete().eq("user_id", userId).eq("place_id", placeId);
    if (placeType === "place") await recomputeTravelDna(supabase, userId);
    return null;
  }

  await supabase
    .from("favorites")
    .upsert(
      { user_id: userId, place_id: placeId, place_type: placeType, status: action },
      { onConflict: "user_id,place_id" }
    );
  if (placeType === "place") await recomputeTravelDna(supabase, userId);
  return action;
}

export async function skipPlace(
  supabase: SupabaseClient,
  userId: string,
  placeId: string,
  placeType: PlaceType
) {
  await supabase
    .from("favorites")
    .upsert(
      { user_id: userId, place_id: placeId, place_type: placeType, status: "skipped" },
      { onConflict: "user_id,place_id" }
    );
  if (placeType === "place") await recomputeTravelDna(supabase, userId);
}

/** יעדי המועדפים של המשתמש לפי סטטוס, עם פרטי התצוגה המלאים. */
export async function getFavoritePlaces(
  userId: string,
  status: FavoriteStatus
): Promise<UnifiedPlace[]> {
  const supabase = createClient();
  const { data: favorites } = await supabase
    .from("favorites")
    .select("place_id")
    .eq("user_id", userId)
    .eq("status", status)
    .order("created_at", { ascending: false });

  if (!favorites || favorites.length === 0) return [];

  const results = await Promise.all(
    favorites.map((favorite) => getUnifiedPlace(favorite.place_id))
  );

  return results.filter((place): place is UnifiedPlace => place !== null);
}

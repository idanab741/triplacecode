﻿import type { SupabaseClient } from "@supabase/supabase-js";
import { getUpcomingEvents } from "@/services/events/ticketmasterService";
import { haversineDistanceKm, estimateTravelMinutes } from "./geo";
import { saveFinalItinerary } from "./sessionService";
import { reviewItinerary } from "./qualityCheckService";
import { generatePersonalizedDescriptions } from "./descriptionService";
import type { TripIntent } from "./tripIntentService";
import type { FinalItinerary, FinalItineraryEvent, FinalItineraryStop, LatLng, TripBuilderStop } from "./types";

interface LikedStopWithPlace extends TripBuilderStop {
  place: {
    id: string;
    name: string;
    latitude: number | null;
    longitude: number | null;
    image_urls: string[];
    price_level: number | null;
    rating: number | null;
    estimated_visit_minutes: number | null;
    opening_hours: string[] | null;
    short_description: string | null;
  } | null;
}

const BUDGET_BAND_MAX_TOTAL: Record<string, number | null> = {
  "0-100": 100,
  "100-300": 300,
  "300-600": 600,
  "600-1000": 1000,
  unlimited: null,
};

/**
 * מבצע אופטימיזציה סופית: מיון גיאוגרפי (nearest-neighbor, Haversine בלבד),
 * חישוב זמני נסיעה מצטברים, ובדיקת תקציב/משך זמן. בלי קריאת Claude - זהו
 * חישוב דטרמיניסטי, לא שיפוט איכותי.
 */
export async function finalizeItinerary(
  supabase: SupabaseClient,
  sessionId: string,
  origin: LatLng,
  budgetBand: string,
  durationBand?: string,
  tripIntent?: TripIntent | null,
  freeText?: string
): Promise<FinalItinerary> {
  const { data: session } = await supabase
    .from("trip_builder_sessions")
    .select("id")
    .eq("id", sessionId)
    .maybeSingle();

  if (!session) throw new Error("ה-session לא נמצא");

const { data: stops } = await supabase
    .from("trip_builder_stops")
.select(
      "*, place:places(id,name,latitude,longitude,image_urls,price_level,rating,estimated_visit_minutes,opening_hours,short_description)"
    )
    .eq("session_id", sessionId)
    .eq("status", "liked")
    .order("slot_index", { ascending: true });

  const likedStops = ((stops ?? []) as LikedStopWithPlace[]).filter(
    (stop) => stop.place && stop.place.latitude != null && stop.place.longitude != null
  );

  // עבור חופשה בחו"ל (יש day_index) - ממיינים לפי יום קודם, ורק בתוך כל
  // יום עושים nearest-neighbor. אחרת (יום בודד) - nearest-neighbor רגיל.
  const hasDays = likedStops.some((s) => s.day_index != null);
  const ordered = hasDays ? orderByDayThenNearestNeighbor(likedStops, origin) : orderByNearestNeighbor(likedStops, origin);

let cursor = origin;
  let cumulativeMinutes = 0;
  let cumulativeCost = 0;
  let previousDay: number | null = null;
  const finalStops: FinalItineraryStop[] = [];

  for (const stop of ordered) {
    // מאפסים את המונה **וגם** את ה-cursor בתחילת כל יום חדש - חוזרים
    // למיקום המוצא (מלון/יעד), לא ממשיכים מהתחנה האחרונה של היום הקודם.
    // בלי זה, מרחק גדול (או שגיאת geocoding נקודתית) בסוף יום אחד "מדביק"
    // את כל התחנות של היום הבא בזמן שגוי שמצטבר קדימה.
    const currentDay = stop.day_index ?? null;
    if (currentDay !== null && currentDay !== previousDay) {
      cumulativeMinutes = 0;
      cursor = origin;
      previousDay = currentDay;
    }

  const placeLatLng: LatLng = { lat: stop.place!.latitude!, lng: stop.place!.longitude! };
    const rawDistanceKm = haversineDistanceKm(cursor, placeLatLng);
    // תקרת שפיות: מרחק בין תחנות בתוך אותו יעד לא אמור לחרוג מ-100 ק"מ.
    // אם זה קורה - כנראה geocoding שגוי למקום ספציפי (נקודת "אפס" או עיר
    // אחרת) - מתעלמים מהמרחק החריג במקום לתת לו "להדביק" זמן ענק לכל השאר.
    const distanceKm = rawDistanceKm > 100 ? 5 : rawDistanceKm;
    const etaMinutes = estimateTravelMinutes(distanceKm, "drive");
    cumulativeMinutes += etaMinutes;

finalStops.push({
        stopId: stop.id,
        placeId: stop.place!.id,
        name: stop.place!.name,
        category: stop.category,
        imageUrls: stop.place!.image_urls ?? [],
        etaMinutes,
        arrivalOffsetMinutes: cumulativeMinutes,
        estimatedVisitMinutes: stop.place!.estimated_visit_minutes,
        priceLevel: stop.place!.price_level,
        rating: stop.place!.rating,
        reason: stop.reason,
        shortDescription: stop.place!.short_description,
        latitude: placeLatLng.lat,
        longitude: placeLatLng.lng,
        openingHours: stop.place!.opening_hours,
        dayIndex: stop.day_index,
    });

    cumulativeMinutes += stop.place!.estimated_visit_minutes ?? 60;
    cumulativeCost += estimateCostFromPriceLevel(stop.place!.price_level);
    cursor = placeLatLng;
  }

const warnings: string[] = [];
  const maxBudget = BUDGET_BAND_MAX_TOTAL[budgetBand];
  if (maxBudget != null && cumulativeCost > maxBudget) {
    warnings.push("העלות המשוערת של המסלול עשויה לחרוג מהתקציב שנבחר");
  }
  
// בקרת איכות אחרונה - רק למסלולים ארוכים יותר, שבהם הסיכון לחוסר איזון גבוה יותר.
  // זהו כלי ניטור פנימי בלבד - הבעיות נרשמות ביומן (Vercel logs) לצורך מעקב איכות,
  // ולא מוצגות למשתמש כאזהרה. משתמש שרואה "רשימת תלונות" על הטיול שלו זו חוויה גרועה.
  if ((durationBand === "half_day" || durationBand === "full_day") && finalStops.length > 0) {
    const issues = await reviewItinerary({ stops: finalStops, tripIntent });
    if (issues.length > 0) {
      console.warn("[Quality Check] נמצאו בעיות איכות במסלול", {
        sessionId,
        issues,
      });
    }
  }

  // תיאורים אישיים - Claude מייצר תיאור לכל תחנה על סמך ידע כללי + הבקשה של
  // המשתמש, לא רק על סמך short_description שיכול להיות ריק/גנרי ב-DB.
  // *** במסלולים גדולים (חופשה רב-ימית, 15+ תחנות) - מדלגים על הקריאה הזו
  // לגמרי. היא קריאת AI *שלישית* ברצף (אחרי "כוונת הטיול" ובניית המסלול
  // עצמה), ויכולה לקחת עד 20-40 שניות בטיול ארוך - וזו בדיוק הסיבה
  // שהמסלול מסומן "מוכן" כל כך מאוחר. ה-reason שכבר נוצר בשלב הדירוג/בחירת
  // התחנות (משפט שמסביר למה המקום מתאים) הוא כבר תיאור סביר - לא "ריק". ***
  const MAX_STOPS_FOR_AI_DESCRIPTIONS = 15;
  if (finalStops.length > 0 && finalStops.length <= MAX_STOPS_FOR_AI_DESCRIPTIONS) {
    const descriptions = await generatePersonalizedDescriptions(finalStops, freeText ?? "", tripIntent);
    for (const stop of finalStops) {
      const generated = descriptions.get(stop.stopId);
      if (generated) {
        stop.shortDescription = generated;
      } else if (!stop.shortDescription && stop.reason) {
        // גיבוי: אם יצירת התיאור נכשלה/נקטעה לתחנה הזו ספציפית - עדיף
        // להציג את ה-reason (כבר קיים, נוצר בשלב הבחירה) מאשר תחנה בלי
        // שום תיאור בכלל.
        stop.shortDescription = stop.reason;
      }
    }
  } else if (finalStops.length > MAX_STOPS_FOR_AI_DESCRIPTIONS) {
    for (const stop of finalStops) {
      if (!stop.shortDescription && stop.reason) {
        stop.shortDescription = stop.reason;
      }
    }
  }

const itinerary: FinalItinerary = {
    stops: finalStops,
    events: [],
    totalEtaMinutes: cumulativeMinutes,
    warnings,
  };

  await saveFinalItinerary(supabase, sessionId, itinerary);
  return itinerary;
}

/**
 * מתחילה מהתחנה **הראשונה בתוכנית המקורית** (כפי ש-Claude קבע לפי סדר
 * slot_index) - לא מהתחנה הכי קרובה גיאוגרפית לבית. זה קריטי כשהמשתמש
 * מבקש רצף מפורש במלל החופשי (למשל "קודם קפה, אחר כך טיול, ואז קניון") -
 * בלי זה, המיון הגיאוגרפי הטהור היה יכול לבחור כל תחנה כפתיחה, ומתעלם
 * לגמרי מהכוונה שהמשתמש ביקש. משם והלאה - nearest-neighbor רגיל, כדי
 * לבנות מסלול יעיל בין שאר התחנות.
 */
function orderByNearestNeighbor(stops: LikedStopWithPlace[], _origin: LatLng): LikedStopWithPlace[] {
  if (stops.length === 0) return [];

  const remaining = [...stops];
  const [first] = remaining.splice(0, 1);
  const ordered: LikedStopWithPlace[] = [first];
  let cursor = { lat: first.place!.latitude!, lng: first.place!.longitude! };

  while (remaining.length > 0) {
    let nearestIndex = 0;
    let nearestDistance = Infinity;

    remaining.forEach((stop, index) => {
      const distance = haversineDistanceKm(cursor, {
        lat: stop.place!.latitude!,
        lng: stop.place!.longitude!,
      });
      if (distance < nearestDistance) {
        nearestDistance = distance;
        nearestIndex = index;
      }
    });

    const [next] = remaining.splice(nearestIndex, 1);
    ordered.push(next);
    cursor = { lat: next.place!.latitude!, lng: next.place!.longitude! };
  }

  return ordered;
}

/** כמו orderByNearestNeighbor, אבל שומר על קיבוץ לפי יום - לא מערבב תחנות מימים שונים. */
function orderByDayThenNearestNeighbor(stops: LikedStopWithPlace[], origin: LatLng): LikedStopWithPlace[] {
  const days = Array.from(new Set(stops.map((s) => s.day_index ?? 0))).sort((a, b) => a - b);
  const ordered: LikedStopWithPlace[] = [];
  let cursor = origin;

  for (const day of days) {
    const dayStops = stops.filter((s) => (s.day_index ?? 0) === day);
    const orderedDay = orderByNearestNeighbor(dayStops, cursor);
    ordered.push(...orderedDay);
    if (orderedDay.length > 0) {
      const last = orderedDay[orderedDay.length - 1];
      cursor = { lat: last.place!.latitude!, lng: last.place!.longitude! };
    }
  }

  return ordered;
}

/**
 * אירועים ופסטיבלים אמיתיים בסביבה (Ticketmaster) - מוצגים כהמלצה משלימה
 * בסוף המסלול, לא כתחנה מוחלקת, כי הם תלויי-תאריך ולא מקום קבוע.
 */
async function fetchNearbyEvents(origin: LatLng): Promise<FinalItineraryEvent[]> {
  try {
    const events = await getUpcomingEvents(origin.lat, origin.lng);
    return events.map((event) => ({
      id: event.id,
      name: event.name,
      date: event.date,
      venueName: event.venueName,
      imageUrl: event.imageUrl,
      url: event.url,
    }));
  } catch {
    return [];
  }
}

function estimateCostFromPriceLevel(priceLevel: number | null): number {
  if (priceLevel == null) return 80;
  return [40, 80, 150, 250, 400][Math.min(priceLevel, 4)] ?? 80;
}


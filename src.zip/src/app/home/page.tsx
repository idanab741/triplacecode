"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { isMainOnboardingComplete, isProfileComplete } from "@/services/profile/profileService";
import { isPreferencesComplete } from "@/services/preferences/preferencesService";
import { getFeaturedDestinations } from "@/services/destinations/destinationsService";
import { getFirstName } from "@/utils/greeting";
import { MainBottomNav } from "@/components/MainBottomNav";
import { HomeHero } from "@/screens/home/HomeHero";
import { HomeHeader } from "@/screens/home/HomeHeader";
import { GreetingBlock } from "@/screens/home/GreetingBlock";
import { SearchBarLink } from "@/screens/home/SearchBarLink";
import { QuickCategories } from "@/screens/home/QuickCategories";
import { DiscoverCard } from "@/screens/home/DiscoverCard";
import { HotDestinations, type Destination } from "@/screens/home/HotDestinations";
import { MyTripsSection } from "@/screens/home/MyTripsSection";

export default function HomePage() {
  const {
    user,
    loading,
    profile,
    profileLoading,
    preferences,
    preferencesLoading,
  } = useAuth();
  const router = useRouter();

  const [destinations, setDestinations] = useState<Destination[]>([]);
  const [personalized, setPersonalized] = useState(false);

  useEffect(() => {
    if (loading || profileLoading || !user) return;

    // אורחים (anonymous auth) אין להם שורת profiles בכלל, ולכן אין להם
    // איך "לזכור" שראו את ה-Onboarding ב-DB - חייבים לדלג עליהם *לפני*
    // הבדיקה למטה, אחרת הם ייתקעו בלולאה (מופנים ל-/onboarding בכל
    // ביקור, כי אין להם profile שאפשר לעדכן בו intro_completed_at).
    const isGuest = Boolean(user.is_anonymous);

    // בפעם הראשונה שמשתמש מגיע לעמוד הבית אחרי התחברות/הרשמה - מציגים
    // קודם את ה-Onboarding (חד-פעמי, לפי profiles.intro_completed_at ב-DB -
    // לא localStorage, כדי שזה יהיה עקבי עם auth/callback/route.ts
    // שרץ בשרת ואין לו גישה ל-localStorage בכלל).
    if (!isGuest && !isMainOnboardingComplete(profile)) {
      router.replace("/onboarding");
      return;
    }

    // אורחים לא אמורים להיזרק אוטומטית להשלמת פרופיל - המטרה של מצב
    // אורח היא שיוכלו לגלוש חופשי בעמוד הבית, ורק אם ילחצו על פעולה
    // שדורשת חשבון אמיתי - שם תופיע הזמנה להירשם (לא אוטומטית).
    if (isGuest) return;

    if (!isProfileComplete(profile)) {
      router.replace("/profile-setup");
    }
  }, [loading, profileLoading, user, profile, router]);

  useEffect(() => {
    getFeaturedDestinations().then((rows) => {
      setDestinations(
        rows
          .filter((row) => row.image_url)
          .map((row) => ({
            id: row.id,
            name: row.name,
            subtitle: row.country,
            imageUrl: row.image_url as string,
          }))
      );
    });
  }, []);

  const isGuest = Boolean(user?.is_anonymous);
  const displayName = isGuest ? null : getFirstName(profile?.full_name);

  useEffect(() => {
    if (isGuest || !user || !isPreferencesComplete(preferences)) return;
    if (destinations.length === 0 || personalized) return;

    let cancelled = false;

    fetch("/api/match/rank-destinations", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ destinationIds: destinations.map((d) => d.id) }),
    })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (cancelled || !data?.results) return;
        const scoreById = new Map(
          (data.results as { destination_id: string; score: number; reason: string }[]).map(
            (r) => [r.destination_id, r]
          )
        );
        setDestinations((prev) =>
          [...prev]
            .map((d) => {
              const match = scoreById.get(d.id);
              return match
                ? { ...d, matchScore: match.score, matchReason: match.reason }
                : d;
            })
            .sort((a, b) => (b.matchScore ?? -1) - (a.matchScore ?? -1))
        );
        setPersonalized(true);
      })
      .catch(() => {
        // אם הדירוג נכשל, פשוט נשארים עם הסדר הכללי - המסך לא נשבר
      });

    return () => {
      cancelled = true;
    };
  }, [isGuest, user, preferences, destinations, personalized]);

  return (
    <div className="min-h-screen bg-bg pb-28">
      <div className="mx-auto max-w-xl">
        {/* בלוק עליון מאוחד: ה-Hero ממשיך בצבע האחיד שלו (#e5e6f4, נדגם מתחתית תמונת ה-Hero)
            עד אחרי הקטגוריות, ורק שם מתעגל ועובר לרקע הרגיל של הדף */}
        <div className="overflow-hidden rounded-b-[50px]" style={{ backgroundColor: "#e5e6f4" }}>
          <HomeHeader avatarUrl={profile?.avatar_url} loading={loading || profileLoading} />
          <HomeHero />

          <div className="flex flex-col pb-6">
            <GreetingBlock name={displayName} loading={loading || profileLoading} />
            <div className="mt-4">
              <SearchBarLink />
            </div>
            <div className="mt-7">
              <QuickCategories />
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-6 pb-4 pt-5">
          <DiscoverCard />
          <HotDestinations
            title={personalized ? "מותאם בשבילך" : "יעדים חמים"}
            destinations={destinations}
          />
          <MyTripsSection />
        </div>
      </div>

      <MainBottomNav active="home" />
    </div>
  );
}

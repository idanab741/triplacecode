"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { useAdminSecret } from "@/screens/admin/shell/AdminAuthContext";
import { AdminField, AdminButton, adminInputClass, adminInputStyle } from "@/screens/admin/shared/Drawer";
import { TRIP_TYPE_GROUPS } from "@/services/places/tripTaxonomy";

const ADMIN_SECRET_HEADER = "x-admin-secret";

interface Place {
  id: string;
  name: string;
  category: string;
  subcategory: string | null;
  short_description: string | null;
  city: string | null;
  country: string | null;
  address: string | null;
  neighborhood: string | null;
  latitude: number | null;
  longitude: number | null;
  rating: number | null;
  rating_count: number | null;
  price_level: number | null;
  average_price: number | null;
  entrance_price: number | null;
  estimated_visit_minutes: number | null;
  recommended_hours: string | null;
  requires_reservation: boolean | null;
  popularity_level: string | null;
  image_urls: string[];
  opening_hours: string[] | null;
  tags: string[];
  phone: string | null;
  website: string | null;
  google_maps_url: string | null;
  trip_type_tags: string[];
  cuisine_tags: string[];
  kosher: boolean | null;
  accessible: boolean | null;
  seasons: string[];
  suitable_child_ages: string[];
  budget_tier: string | null;
  place_type_key: string | null;
  audience_fit: string[] | null;
  dna_tags: string[] | null;
  weather_fit: string[] | null;
  accessibility_features: string[] | null;
  pet_friendliness_features: string[] | null;
  type_attributes: Record<string, unknown> | null;
}

interface FieldDef {
  id: string;
  place_type: string;
  field_key: string;
  label_he: string;
  field_type: "number" | "text" | "boolean" | "single_select" | "multi_select";
  options: { value: string; label_he: string }[] | null;
}

const TABS = [
  { key: "general", label: "מידע כללי" },
  { key: "categories", label: "קטגוריות" },
  { key: "matching", label: "התאמות" },
  { key: "ai", label: "AI" },
  { key: "images", label: "תמונות" },
  { key: "location", label: "מיקום" },
] as const;

type TabKey = (typeof TABS)[number]["key"];

/** Workspace מלא לעריכת מקום בודד - טאבים, לא Drawer שטוח. תבנית ראשונה
 *  (מודול "מסעדות ובתי קפה") - תשוכפל לשאר 7 המודולים אחרי אישור. */
export default function PlaceWorkspacePage() {
  const { secret: adminSecret } = useAdminSecret();
  const params = useParams();
  const router = useRouter();
  const id = params.id as string;

  const [place, setPlace] = useState<Place | null>(null);
  const [fieldDefs, setFieldDefs] = useState<FieldDef[]>([]);
  const [tab, setTab] = useState<TabKey>("general");
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [aiSuggesting, setAiSuggesting] = useState(false);

  useEffect(() => {
    if (!adminSecret || !id) return;
    fetch(`/api/admin/places/${id}`, { headers: { [ADMIN_SECRET_HEADER]: adminSecret } })
      .then((res) => res.json())
      .then((data) => {
        if (data.error) throw new Error(data.error);
        setPlace(data.place);
      })
      .catch((e) => setError(e instanceof Error ? e.message : "שגיאה בטעינת המקום"));
  }, [adminSecret, id]);

  useEffect(() => {
    if (!adminSecret || !place?.place_type_key) return;
    fetch(`/api/admin/place-type-fields?place_type=${place.place_type_key}`, {
      headers: { [ADMIN_SECRET_HEADER]: adminSecret },
    })
      .then((res) => res.json())
      .then((data) => setFieldDefs(data.fieldDefs ?? []))
      .catch(() => setFieldDefs([]));
  }, [adminSecret, place?.place_type_key]);

  function update<K extends keyof Place>(key: K, value: Place[K]) {
    setPlace((p) => (p ? { ...p, [key]: value } : p));
  }

  async function handleSave() {
    if (!place) return;
    setSaving(true);
    setError(null);
    try {
      const { id: placeId, ...rest } = place;
      const res = await fetch(`/api/admin/places/${placeId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", [ADMIN_SECRET_HEADER]: adminSecret },
        body: JSON.stringify(rest),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setPlace(data.place);
      setSavedAt(Date.now());
    } catch (e) {
      setError(e instanceof Error ? e.message : "שמירה נכשלה");
    } finally {
      setSaving(false);
    }
  }

  async function handleAiComplete() {
    if (!place) return;
    setAiSuggesting(true);
    setError(null);
    try {
      const res = await fetch(`/api/admin/places/${place.id}/suggest-tags`, {
        method: "POST",
        headers: { [ADMIN_SECRET_HEADER]: adminSecret },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "השלמת AI נכשלה");
      // ה-AI לעולם לא שומר לבד - רק ממלא את הטופס המקומי. עדיין צריך
      // ללחוץ "שמור שינויים" למעלה כדי לאשר ולפרסם בפועל.
      const s = data.suggestion;
      setPlace((p) =>
        p
          ? {
              ...p,
              trip_type_tags: s.trip_type_tags ?? p.trip_type_tags,
              cuisine_tags: s.cuisine_tags ?? p.cuisine_tags,
              kosher: s.kosher ?? p.kosher,
              accessible: s.accessible ?? p.accessible,
              seasons: s.seasons ?? p.seasons,
              suitable_child_ages: s.suitable_child_ages ?? p.suitable_child_ages,
              budget_tier: s.budget_tier ?? p.budget_tier,
            }
          : p
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : "השלמת AI נכשלה");
    } finally {
      setAiSuggesting(false);
    }
  }

  if (error && !place) {
    return (
      <div className="p-6">
        <p className="text-[13.5px] text-red-600">{error}</p>
        <Link href="/admin/places" className="mt-3 inline-block text-[13.5px]" style={{ color: "var(--admin-accent)" }}>
          → חזרה לרשימת המקומות
        </Link>
      </div>
    );
  }

  if (!place) {
    return <p className="p-6 text-[13.5px]" style={{ color: "var(--admin-ink-secondary)" }}>טוען...</p>;
  }

  return (
    <div className="flex h-full flex-col">
      {/* Header */}
      <div className="flex items-center justify-between border-b px-6 py-4" style={{ borderColor: "var(--admin-border)" }}>
        <div>
          <button
            type="button"
            onClick={() => router.push("/admin/places")}
            className="mb-1 text-[12.5px]"
            style={{ color: "var(--admin-ink-secondary)" }}
          >
            → כל המקומות
          </button>
          <h1 className="text-[19px] font-semibold" style={{ color: "var(--admin-ink)" }}>
            {place.name}
          </h1>
        </div>
        <div className="flex items-center gap-3">
          {savedAt && Date.now() - savedAt < 3000 && (
            <span className="text-[12.5px]" style={{ color: "var(--admin-success, #16A34A)" }}>
              ✓ נשמר
            </span>
          )}
          {error && <span className="text-[12.5px] text-red-600">{error}</span>}
          <AdminButton onClick={handleSave} disabled={saving}>
            {saving ? "שומר..." : "שמור שינויים"}
          </AdminButton>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b px-6" style={{ borderColor: "var(--admin-border)" }}>
        {TABS.map((t) => (
          <button
            key={t.key}
            type="button"
            onClick={() => setTab(t.key)}
            className="px-3 py-2.5 text-[13.5px] font-medium transition"
            style={{
              color: tab === t.key ? "var(--admin-accent)" : "var(--admin-ink-secondary)",
              borderBottom: tab === t.key ? "2px solid var(--admin-accent)" : "2px solid transparent",
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="admin-scrollbar flex-1 overflow-y-auto p-6">
        {tab === "general" && (
          <div className="grid max-w-2xl grid-cols-2 gap-4">
            <AdminField label="שם המקום">
              <input className={adminInputClass} style={adminInputStyle} value={place.name} onChange={(e) => update("name", e.target.value)} />
            </AdminField>
            <AdminField label="עיר">
              <input className={adminInputClass} style={adminInputStyle} value={place.city ?? ""} onChange={(e) => update("city", e.target.value)} />
            </AdminField>
            <AdminField label="מדינה">
              <input className={adminInputClass} style={adminInputStyle} value={place.country ?? ""} onChange={(e) => update("country", e.target.value)} />
            </AdminField>
            <AdminField label="שכונה/אזור">
              <input className={adminInputClass} style={adminInputStyle} value={place.neighborhood ?? ""} onChange={(e) => update("neighborhood", e.target.value)} />
            </AdminField>
            <div className="col-span-2">
              <AdminField label="כתובת מלאה">
                <input className={adminInputClass} style={adminInputStyle} value={place.address ?? ""} onChange={(e) => update("address", e.target.value)} />
              </AdminField>
            </div>
            <div className="col-span-2">
              <AdminField label="תיאור קצר">
                <textarea
                  className={adminInputClass}
                  style={{ ...adminInputStyle, minHeight: 70 }}
                  value={place.short_description ?? ""}
                  onChange={(e) => update("short_description", e.target.value)}
                />
              </AdminField>
            </div>
            <AdminField label="טלפון">
              <input className={adminInputClass} style={adminInputStyle} value={place.phone ?? ""} onChange={(e) => update("phone", e.target.value)} />
            </AdminField>
            <AdminField label="אתר">
              <input className={adminInputClass} style={adminInputStyle} value={place.website ?? ""} onChange={(e) => update("website", e.target.value)} />
            </AdminField>
            <AdminField label="דירוג">
              <input
                type="number"
                step="0.1"
                className={adminInputClass}
                style={adminInputStyle}
                value={place.rating ?? ""}
                onChange={(e) => update("rating", e.target.value ? Number(e.target.value) : null)}
              />
            </AdminField>
            <AdminField label="מספר ביקורות">
              <input
                type="number"
                className={adminInputClass}
                style={adminInputStyle}
                value={place.rating_count ?? ""}
                onChange={(e) => update("rating_count", e.target.value ? Number(e.target.value) : null)}
              />
            </AdminField>
            <AdminField label="מחיר ממוצע (₪)">
              <input
                type="number"
                className={adminInputClass}
                style={adminInputStyle}
                value={place.average_price ?? ""}
                onChange={(e) => update("average_price", e.target.value ? Number(e.target.value) : null)}
              />
            </AdminField>
            <AdminField label="מחיר כניסה (₪)">
              <input
                type="number"
                className={adminInputClass}
                style={adminInputStyle}
                value={place.entrance_price ?? ""}
                onChange={(e) => update("entrance_price", e.target.value ? Number(e.target.value) : null)}
              />
            </AdminField>
            <AdminField label="שעות מומלצות">
              <input className={adminInputClass} style={adminInputStyle} value={place.recommended_hours ?? ""} onChange={(e) => update("recommended_hours", e.target.value)} />
            </AdminField>
            <AdminField label="דורש הזמנה מראש">
              <select
                className={adminInputClass}
                style={adminInputStyle}
                value={place.requires_reservation === null ? "" : String(place.requires_reservation)}
                onChange={(e) => update("requires_reservation", e.target.value === "" ? null : e.target.value === "true")}
              >
                <option value="">לא ידוע</option>
                <option value="true">כן</option>
                <option value="false">לא</option>
              </select>
            </AdminField>
          </div>
        )}

        {tab === "categories" && (
          <div className="grid max-w-2xl grid-cols-2 gap-4">
            <AdminField label="קטגוריה ראשית">
              <select className={adminInputClass} style={adminInputStyle} value={place.category} onChange={(e) => update("category", e.target.value)}>
                {TRIP_TYPE_GROUPS.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.label}
                  </option>
                ))}
              </select>
            </AdminField>
            <AdminField label="תת-קטגוריה">
              <input className={adminInputClass} style={adminInputStyle} value={place.subcategory ?? ""} onChange={(e) => update("subcategory", e.target.value)} />
            </AdminField>
            <div className="col-span-2">
              <AdminField label="סוג יעד (place_type_key) - קובע אילו שדות AI מוצגים בטאב AI">
                <input className={adminInputClass} style={adminInputStyle} value={place.place_type_key ?? ""} onChange={(e) => update("place_type_key", e.target.value)} />
              </AdminField>
            </div>
            <div className="col-span-2">
              <AdminField label="תגיות סוג טיול (trip_type_tags, מופרד בפסיקים)">
                <input
                  className={adminInputClass}
                  style={adminInputStyle}
                  value={place.trip_type_tags.join(", ")}
                  onChange={(e) => update("trip_type_tags", e.target.value.split(",").map((s) => s.trim()).filter(Boolean))}
                />
              </AdminField>
            </div>
            <div className="col-span-2">
              <AdminField label="תגיות מטבח (cuisine_tags, מופרד בפסיקים)">
                <input
                  className={adminInputClass}
                  style={adminInputStyle}
                  value={place.cuisine_tags.join(", ")}
                  onChange={(e) => update("cuisine_tags", e.target.value.split(",").map((s) => s.trim()).filter(Boolean))}
                />
              </AdminField>
            </div>
          </div>
        )}

        {tab === "matching" && (
          <div className="grid max-w-2xl grid-cols-2 gap-4">
            <AdminField label="כשר">
              <select
                className={adminInputClass}
                style={adminInputStyle}
                value={place.kosher === null ? "" : String(place.kosher)}
                onChange={(e) => update("kosher", e.target.value === "" ? null : e.target.value === "true")}
              >
                <option value="">לא ידוע</option>
                <option value="true">כן</option>
                <option value="false">לא</option>
              </select>
            </AdminField>
            <AdminField label="נגיש">
              <select
                className={adminInputClass}
                style={adminInputStyle}
                value={place.accessible === null ? "" : String(place.accessible)}
                onChange={(e) => update("accessible", e.target.value === "" ? null : e.target.value === "true")}
              >
                <option value="">לא ידוע</option>
                <option value="true">כן</option>
                <option value="false">לא</option>
              </select>
            </AdminField>
            <AdminField label="רמת תקציב">
              <input className={adminInputClass} style={adminInputStyle} value={place.budget_tier ?? ""} onChange={(e) => update("budget_tier", e.target.value)} />
            </AdminField>
            <AdminField label="רמת פופולריות">
              <input className={adminInputClass} style={adminInputStyle} value={place.popularity_level ?? ""} onChange={(e) => update("popularity_level", e.target.value)} />
            </AdminField>
            <div className="col-span-2">
              <AdminField label="גילאי ילדים מתאימים (מופרד בפסיקים)">
                <input
                  className={adminInputClass}
                  style={adminInputStyle}
                  value={place.suitable_child_ages.join(", ")}
                  onChange={(e) => update("suitable_child_ages", e.target.value.split(",").map((s) => s.trim()).filter(Boolean))}
                />
              </AdminField>
            </div>
            <div className="col-span-2">
              <AdminField label="עונות מתאימות (מופרד בפסיקים)">
                <input
                  className={adminInputClass}
                  style={adminInputStyle}
                  value={place.seasons.join(", ")}
                  onChange={(e) => update("seasons", e.target.value.split(",").map((s) => s.trim()).filter(Boolean))}
                />
              </AdminField>
            </div>
          </div>
        )}

        {tab === "ai" && (
          <div className="flex max-w-2xl flex-col gap-4">
            <div
              className="flex items-center justify-between rounded-[var(--admin-radius-lg)] border p-4"
              style={{ borderColor: "var(--admin-border)", background: "var(--admin-bg-surface)" }}
            >
              <div>
                <p className="text-[14px] font-medium" style={{ color: "var(--admin-ink)" }}>
                  ✨ השלמת תגיות עם AI
                </p>
                <p className="mt-0.5 text-[12.5px]" style={{ color: "var(--admin-ink-secondary)" }}>
                  Claude ינתח את שם/תיאור המקום וישלים תגיות (טיול, מטבח, DNA) - תמיד יוצג לך לפני שמירה, לא נשמר אוטומטית.
                </p>
              </div>
              <AdminButton onClick={handleAiComplete} disabled={aiSuggesting}>
                {aiSuggesting ? "מנתח..." : "✨ השלם עם AI"}
              </AdminButton>
            </div>

            {fieldDefs.length > 0 ? (
              <div className="grid grid-cols-2 gap-4">
                {fieldDefs.map((fd) => (
                  <AdminField key={fd.id} label={fd.label_he}>
                    <input
                      className={adminInputClass}
                      style={adminInputStyle}
                      value={String((place.type_attributes ?? {})[fd.field_key] ?? "")}
                      onChange={(e) =>
                        update("type_attributes", { ...(place.type_attributes ?? {}), [fd.field_key]: e.target.value })
                      }
                    />
                  </AdminField>
                ))}
              </div>
            ) : (
              <p className="text-[13px]" style={{ color: "var(--admin-ink-secondary)" }}>
                {place.place_type_key
                  ? "אין שדות ייעודיים מוגדרים לסוג היעד הזה עדיין - הגדר ב-/admin/place-type-fields"
                  : "יש להגדיר קודם place_type_key בטאב קטגוריות כדי לראות שדות ייעודיים"}
              </p>
            )}
          </div>
        )}

        {tab === "images" && (
          <div className="max-w-2xl">
            <div className="grid grid-cols-3 gap-3">
              {place.image_urls.map((url, i) => (
                <div key={i} className="group relative overflow-hidden rounded-[var(--admin-radius-md)] border" style={{ borderColor: "var(--admin-border)" }}>
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={url} alt="" className="h-32 w-full object-cover" />
                  <button
                    type="button"
                    onClick={() => update("image_urls", place.image_urls.filter((_, idx) => idx !== i))}
                    className="absolute left-1 top-1 flex h-6 w-6 items-center justify-center rounded-full bg-black/60 text-white opacity-0 transition group-hover:opacity-100"
                  >
                    ✕
                  </button>
                  {i === 0 && (
                    <span className="absolute bottom-1 right-1 rounded-full bg-black/60 px-2 py-0.5 text-[10px] text-white">ראשית</span>
                  )}
                </div>
              ))}
            </div>
            <div className="mt-4">
              <AdminField label="הוסף תמונה (URL)">
                <div className="flex gap-2">
                  <input
                    id="new-image-url"
                    className={adminInputClass}
                    style={adminInputStyle}
                    placeholder="https://..."
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        const val = (e.target as HTMLInputElement).value.trim();
                        if (val) {
                          update("image_urls", [...place.image_urls, val]);
                          (e.target as HTMLInputElement).value = "";
                        }
                      }
                    }}
                  />
                </div>
              </AdminField>
            </div>
          </div>
        )}

        {tab === "location" && (
          <div className="grid max-w-2xl grid-cols-2 gap-4">
            <AdminField label="קו רוחב (latitude)">
              <input
                type="number"
                step="0.000001"
                className={adminInputClass}
                style={adminInputStyle}
                value={place.latitude ?? ""}
                onChange={(e) => update("latitude", e.target.value ? Number(e.target.value) : null)}
              />
            </AdminField>
            <AdminField label="קו אורך (longitude)">
              <input
                type="number"
                step="0.000001"
                className={adminInputClass}
                style={adminInputStyle}
                value={place.longitude ?? ""}
                onChange={(e) => update("longitude", e.target.value ? Number(e.target.value) : null)}
              />
            </AdminField>
            {place.latitude && place.longitude && (
              <div className="col-span-2 overflow-hidden rounded-[var(--admin-radius-md)] border" style={{ borderColor: "var(--admin-border)" }}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={`/api/places/static-map?lat=${place.latitude}&lng=${place.longitude}`}
                  alt="מפה"
                  className="h-48 w-full object-cover"
                />
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

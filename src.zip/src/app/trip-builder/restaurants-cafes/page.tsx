"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Button, ChipGroup, Field, Screen, Slider } from "@/components/ui";
import { useAuth } from "@/hooks/useAuth";
import { RESTAURANTS_CAFES_QUESTIONS } from "@/services/tripBuilder/rules/restaurantsCafes";
import type { RestaurantAnswers } from "@/services/tripBuilder/types";
import { ChatHeader } from "@/screens/trip-builder/chat/ChatHeader";
import { ChatBubble } from "@/screens/trip-builder/chat/ChatBubble";
import { UserBubble } from "@/screens/trip-builder/chat/UserBubble";
import { TypingIndicator } from "@/screens/trip-builder/chat/TypingIndicator";
import { AnswerOptions } from "@/screens/trip-builder/chat/AnswerOptions";
import { MainBottomNav } from "@/components/MainBottomNav";
import Image from "next/image";

type TripChoice = "triplace" | "tripmatch";

const DEFAULT_ANSWERS: RestaurantAnswers = {
  companions: "solo",
  hasPet: false,
  childAgeBands: [],
  timing: "today",
  otherDate: null,
  distanceBand: "1h",
  budgetBand: "300-600",
  cuisine: [],
  freeText: "",
};

type EditableFieldKey =
  | "companions"
  | "childAgeBands"
  | "timing"
  | "distanceBand"
  | "budgetBand"
  | "cuisine"
  | "freeText";

type ChatMessage = {
  id: number;
  role: "assistant" | "user" | "icon";
  text: string;
  fieldKey?: EditableFieldKey;
};

/** עיגול אווטאר קטן ליד כל הודעת משתמש — תמונת פרופיל אם קיימת, אחרת אות ראשונה. */
function UserAvatar({ avatarUrl, name }: { avatarUrl: string | null; name: string | null }) {
  const initial = name?.trim()?.[0]?.toUpperCase() ?? "👤";

  if (avatarUrl) {
    return (
      <div className="relative h-7 w-7 shrink-0 overflow-hidden rounded-full ring-1 ring-black/5">
        <Image src={avatarUrl} alt="" fill className="object-cover" />
      </div>
    );
  }

  return (
    <div
      className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-semibold text-white"
      style={{ background: "linear-gradient(135deg, var(--color-primary-start), var(--color-primary-end))" }}
    >
      {initial}
    </div>
  );
}

/** שתי כרטיסיות לוגו לבחירה בין TripPlace (אוטומטי) ל-TripMatch (החלקות). */
function TripChoiceCards({
  onChoose,
  disabled,
}: {
  onChoose: (choice: TripChoice) => void;
  disabled: boolean;
}) {
  return (
    <div className="flex gap-3">
      <button
        type="button"
        onClick={() => onChoose("triplace")}
        disabled={disabled}
        className="flex-1 rounded-card bg-white p-4 shadow-soft transition active:scale-95 disabled:opacity-50"
      >
        <div className="relative mx-auto h-8 w-full">
          <Image src="/images/trip-triplace-logo.png" alt="TripPlace" fill className="object-contain" />
        </div>
        <p className="mt-2 text-center text-[11px] text-ink-secondary">ה-AI בונה הכל אוטומטית</p>
      </button>

      <button
        type="button"
        onClick={() => onChoose("tripmatch")}
        disabled={disabled}
        className="flex-1 rounded-card bg-white p-4 shadow-soft transition active:scale-95 disabled:opacity-50"
      >
        <div className="relative mx-auto h-8 w-full">
          <Image src="/images/trip-tripmatch-logo.png" alt="TripMatch" fill className="object-contain" />
        </div>
        <p className="mt-2 text-center text-[11px] text-ink-secondary">בוחרים לבד עם החלקות</p>
      </button>
    </div>
  );
}

/** תג שמציג את סוג הטיול, בצד שמאל — כמו תשובות המשתמש, עם גרדיאנט המותג. */
function TripTypeBadge({ label }: { label: string }) {
  return (
    <div className="flex justify-end">
      <div
        className="flex items-center gap-2 rounded-pill px-3 py-2"
        style={{
          background: "linear-gradient(135deg, var(--color-primary-start), var(--color-primary-end))",
          boxShadow: "0 4px 12px rgba(24,119,242,0.28)",
        }}
      >
        <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-white/20 text-base">
          🍽️
        </div>
        <span className="text-[13.5px] font-medium text-white">{label}</span>
      </div>
    </div>
  );
}

export default function RestaurantsCafesQuestionnairePage() {
  const router = useRouter();
  const { user, profile } = useAuth();

  const [stepIndex, setStepIndex] = useState(0);
  const [form, setForm] = useState<RestaurantAnswers>(DEFAULT_ANSWERS);
  const [submitting, setSubmitting] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [awaitingTripChoice, setAwaitingTripChoice] = useState(false);
  const [busyChoice, setBusyChoice] = useState(false);

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [typing, setTyping] = useState(false);
  const [awaitingChildAges, setAwaitingChildAges] = useState(false);
  const [awaitingOtherDate, setAwaitingOtherDate] = useState(false);
  const [tempMulti, setTempMulti] = useState<string[]>([]);
  const [tempSlider, setTempSlider] = useState<string | null>(null);
  const [tempText, setTempText] = useState("");
  const [tempCompanion, setTempCompanion] = useState<string | null>(null);
  const [tempHasPet, setTempHasPet] = useState(false);

  const [editingFieldKey, setEditingFieldKey] = useState<EditableFieldKey | null>(null);
  const [editingMessageId, setEditingMessageId] = useState<number | null>(null);
  const [editTempValue, setEditTempValue] = useState<string | null>(null);
  const [editTempSlider, setEditTempSlider] = useState<string | null>(null);
  const [editTempMulti, setEditTempMulti] = useState<string[]>([]);
  const [editTempText, setEditTempText] = useState("");
  const [editTempCompanion, setEditTempCompanion] = useState<string | null>(null);
  const [editTempHasPet, setEditTempHasPet] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const idRef = useRef(0);
  const startedRef = useRef(false);

  const step = RESTAURANTS_CAFES_QUESTIONS[stepIndex];
  const isLastStep = stepIndex === RESTAURANTS_CAFES_QUESTIONS.length - 1;

  function nextId() {
    idRef.current += 1;
    return idRef.current;
  }
  function addBot(text: string, fieldKey?: EditableFieldKey) {
    setMessages((m) => [...m, { id: nextId(), role: "assistant", text, fieldKey }]);
  }
  function addUser(text: string, fieldKey?: EditableFieldKey) {
    setMessages((m) => [...m, { id: nextId(), role: "user", text, fieldKey }]);
  }
  function addIconBadge(label: string) {
    setMessages((m) => [...m, { id: nextId(), role: "icon", text: label }]);
  }

  useEffect(() => {
    if (startedRef.current) return;
    startedRef.current = true;
    addBot(
      "שלום! אני טריפי AI 👋\nבואו נמצא ביחד את המסעדה או בית הקפה המושלמים בשבילכם, בדיוק לרגע הזה."
    );
    addIconBadge("מסעדות ובתי קפה");
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      addBot(RESTAURANTS_CAFES_QUESTIONS[0].title);
    }, 900);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, typing]);

  function updateField<K extends keyof RestaurantAnswers>(key: K, value: RestaurantAnswers[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function labelFor(options: { value: string; label: string }[] | undefined, value: string) {
    return options?.find((o) => o.value === value)?.label ?? value;
  }

  function labelsFor(options: { value: string; label: string }[] | undefined, values: string[]) {
    return values.map((v) => labelFor(options, v));
  }

  function resetTempAnswerState() {
    setTempMulti([]);
    setTempSlider(null);
    setTempText("");
    setTempCompanion(null);
    setTempHasPet(false);
    setAwaitingChildAges(false);
    setAwaitingOtherDate(false);
  }

  function goToNextStep() {
    resetTempAnswerState();
    if (isLastStep) {
      promptTripChoice();
      return;
    }
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      setStepIndex((i) => i + 1);
    }, 550);
  }

  useEffect(() => {
    if (stepIndex === 0) return;
    addBot(RESTAURANTS_CAFES_QUESTIONS[stepIndex].title);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stepIndex]);

  function handleCompanionsSelect(value: string) {
    setTempCompanion(value);
  }

  function togglePet() {
    setTempHasPet((v) => !v);
  }

  function confirmCompanions() {
    if (step.type !== "companions" || !tempCompanion) return;
    updateField("companions", tempCompanion as RestaurantAnswers["companions"]);
    updateField("hasPet", tempHasPet);

    const label = labelFor(step.options, tempCompanion);
    addUser(tempHasPet ? `${label} · 🐶 עם בעל חיים` : label, "companions");

    if (tempCompanion === step.childAgeTriggerValue) {
      setAwaitingChildAges(true);
      setTyping(true);
      setTimeout(() => {
        setTyping(false);
        addBot(step.childAgeTitle, "childAgeBands");
      }, 500);
      return;
    }
    goToNextStep();
  }

  function confirmChildAges() {
    if (step.type !== "companions") return;
    updateField("childAgeBands", tempMulti as RestaurantAnswers["childAgeBands"]);
    addUser(
      tempMulti.length > 0 ? labelsFor(step.childAgeOptions, tempMulti).join("، ") : "לא רלוונטי",
      "childAgeBands"
    );
    goToNextStep();
  }

  function handleDateSelect(value: string) {
    if (step.type !== "date") return;
    updateField("timing", value as RestaurantAnswers["timing"]);
    const label = labelFor(step.options, value);
    addUser(label, "timing");

    if (value === step.otherDateTriggerValue) {
      setAwaitingOtherDate(true);
      return;
    }
    goToNextStep();
  }

  function confirmOtherDate() {
    if (!tempText) return;
    updateField("otherDate", tempText);
    addUser(tempText);
    goToNextStep();
  }

  function confirmSlider() {
    if (step.type !== "slider") return;
    const value = tempSlider ?? (form[step.key as keyof RestaurantAnswers] as string) ?? step.steps[0];
    updateField(step.key as keyof RestaurantAnswers, value as never);
    const label = labelFor(step.steps as unknown as { value: string; label: string }[], value);
    addUser(label, step.key as EditableFieldKey);
    goToNextStep();
  }

  function confirmCuisine() {
    if (step.type !== "multi-emoji") return;
    updateField("cuisine", tempMulti);
    addUser(tempMulti.length > 0 ? labelsFor(step.options, tempMulti).join("، ") : "תפתיע אותי", "cuisine");
    goToNextStep();
  }

  function confirmFreeText() {
    updateField("freeText", tempText);
    addUser(tempText || "—", "freeText");
    goToNextStep();
  }

  function getEditQuestionTitle(key: EditableFieldKey): string {
    if (key === "childAgeBands") {
      const companionsStep = RESTAURANTS_CAFES_QUESTIONS.find((q) => q.key === "companions");
      return companionsStep && companionsStep.type === "companions" ? companionsStep.childAgeTitle : "";
    }
    const editStep = RESTAURANTS_CAFES_QUESTIONS.find((q) => q.key === key);
    return editStep?.title ?? "";
  }

  function openEdit(message: ChatMessage) {
    if (!message.fieldKey || typing || submitting || editingFieldKey) return;
    const key = message.fieldKey;
    setEditingFieldKey(key);
    setEditingMessageId(message.id);

    if (key === "companions") {
      setEditTempCompanion(form.companions);
      setEditTempHasPet(form.hasPet);
    } else if (key === "childAgeBands" || key === "cuisine") {
      setEditTempMulti(key === "childAgeBands" ? form.childAgeBands : form.cuisine);
    } else if (key === "distanceBand" || key === "budgetBand") {
      setEditTempSlider(form[key] as string);
    } else if (key === "freeText") {
      setEditTempText(form.freeText);
    } else if (key === "timing") {
      setEditTempValue(form.timing);
      setEditTempText(form.otherDate ?? "");
    } else {
      setEditTempValue(form[key] as string);
    }
  }

  function closeEdit() {
    setEditingFieldKey(null);
    setEditingMessageId(null);
    setEditTempValue(null);
    setEditTempSlider(null);
    setEditTempMulti([]);
    setEditTempText("");
    setEditTempCompanion(null);
    setEditTempHasPet(false);
  }

  function confirmEdit() {
    if (!editingFieldKey || editingMessageId == null) return;
    const key = editingFieldKey;
    const editStep = RESTAURANTS_CAFES_QUESTIONS.find((q) => q.key === (key === "childAgeBands" ? "companions" : key));
    if (!editStep) return;

    let newLabel = "";

    if (key === "companions" && editStep.type === "companions") {
      if (!editTempCompanion) return;
      updateField("companions", editTempCompanion as RestaurantAnswers["companions"]);
      updateField("hasPet", editTempHasPet);
      const label = labelFor(editStep.options, editTempCompanion);
      newLabel = editTempHasPet ? `${label} · 🐶 עם בעל חיים` : label;

      if (editTempCompanion !== editStep.childAgeTriggerValue) {
        updateField("childAgeBands", [] as RestaurantAnswers["childAgeBands"]);
        setMessages((msgs) => msgs.filter((m) => m.fieldKey !== "childAgeBands"));
      }
    } else if (key === "timing" && editStep.type === "date") {
      if (!editTempValue) return;
      if (editTempValue === editStep.otherDateTriggerValue) {
        if (!editTempText) return;
        updateField("timing", editTempValue as RestaurantAnswers["timing"]);
        updateField("otherDate", editTempText);
        newLabel = editTempText;
      } else {
        updateField("timing", editTempValue as RestaurantAnswers["timing"]);
        newLabel = labelFor(editStep.options, editTempValue);
      }
    } else if ((key === "distanceBand" || key === "budgetBand") && editStep.type === "slider") {
      const value = editTempSlider ?? (form[key] as string);
      updateField(key, value as never);
      newLabel = labelFor(editStep.steps as unknown as { value: string; label: string }[], value);
    } else if (key === "cuisine" && editStep.type === "multi-emoji") {
      updateField("cuisine", editTempMulti);
      newLabel = editTempMulti.length > 0 ? labelsFor(editStep.options, editTempMulti).join("، ") : "תפתיע אותי";
    } else if (key === "childAgeBands" && editStep.type === "companions") {
      updateField("childAgeBands", editTempMulti as RestaurantAnswers["childAgeBands"]);
      newLabel = editTempMulti.length > 0 ? labelsFor(editStep.childAgeOptions, editTempMulti).join("، ") : "לא רלוונטי";
    } else if (key === "freeText") {
      updateField("freeText", editTempText);
      newLabel = editTempText || "—";
    }

    setMessages((msgs) => msgs.map((m) => (m.id === editingMessageId ? { ...m, text: newLabel } : m)));
    closeEdit();
  }

  function promptTripChoice() {
    if (!user) {
      router.push("/auth");
      return;
    }
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      addBot("מעולה! עכשיו תבחרו איך תרצו למצוא את המקום:");
      setAwaitingTripChoice(true);
    }, 700);
  }

  async function handleTripChoice(choice: TripChoice) {
    if (busyChoice) return;
    setBusyChoice(true);
    setLocationError(null);

    try {
      const origin = await getCurrentPosition();
      const response = await fetch("/api/trip-builder/sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tripType: "restaurants_cafes", answers: form, origin }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "יצירת החיפוש נכשלה");

      const sessionId = data.session.id;

      if (choice === "tripmatch") {
        router.push(`/trip-builder/day-trip/build?sessionId=${sessionId}`);
        return;
      }

      setSubmitting(true);
      const buildResponse = await fetch(`/api/trip-builder/sessions/${sessionId}/auto-build`, {
        method: "POST",
      });
      const buildData = await buildResponse.json();
      if (!buildResponse.ok) throw new Error(buildData.error ?? "החיפוש נכשל");
router.push(`/trip-builder/restaurants-cafes/result?sessionId=${sessionId}`);
    } catch (error) {
      setLocationError(
        error instanceof Error ? error.message : "לא הצלחנו למצוא מקום. יש לאשר גישה למיקום ולנסות שוב."
      );
      setBusyChoice(false);
      setSubmitting(false);
    }
  }

  function getFooterAction(): { label: string; onClick: () => void; disabled?: boolean } | null {
    if (typing || submitting) return null;
    if (step.type === "companions" && awaitingChildAges) {
      return { label: "המשך", onClick: confirmChildAges };
    }
    if (step.type === "companions" && !awaitingChildAges) {
      return { label: "המשך", onClick: confirmCompanions, disabled: !tempCompanion };
    }
    if (step.type === "date" && awaitingOtherDate) {
      return { label: "המשך", onClick: confirmOtherDate, disabled: !tempText };
    }
    if (step.type === "slider") {
      return { label: "בחרתי", onClick: confirmSlider };
    }
    if (step.type === "multi-emoji") {
      return { label: "המשך", onClick: confirmCuisine };
    }
    if (step.type === "text") {
      return { label: "המשך", onClick: confirmFreeText };
    }
    return null;
  }

  const footerAction = getFooterAction();

  return (
<Screen withBottomNavSpacing>
          <div className="-mx-5 -mt-8">
        <ChatHeader current={stepIndex + 1} total={RESTAURANTS_CAFES_QUESTIONS.length} onBack={() => router.push("/home")} />
      </div>

      <div className="mx-auto flex max-w-md flex-col gap-4 px-1 pt-4 pb-64">
        {messages.map((m) => {
          if (editingFieldKey && m.id === editingMessageId) {
            return (
              <div key={m.id} className="mt-1">
                {editingFieldKey === "companions" &&
                  (() => {
                    const editStep = RESTAURANTS_CAFES_QUESTIONS.find((q) => q.key === "companions");
                    if (!editStep || editStep.type !== "companions") return null;
                    return (
                      <div className="flex flex-col gap-3">
                        <AnswerOptions options={editStep.options} selected={editTempCompanion} onSelect={setEditTempCompanion} />
                        <button
                          type="button"
                          onClick={() => setEditTempHasPet((v) => !v)}
                          className="flex w-fit items-center gap-1.5 rounded-pill border px-3.5 py-2 text-[13px] font-medium transition active:scale-95"
                          style={{
                            borderColor: "#9C6B30",
                            background: editTempHasPet ? "#9C6B30" : "#ffffff",
                            color: editTempHasPet ? "#ffffff" : "#9C6B30",
                          }}
                        >
                          🐶 עם בעל חיים
                        </button>
                      </div>
                    );
                  })()}

                {editingFieldKey === "childAgeBands" &&
                  (() => {
                    const companionsStep = RESTAURANTS_CAFES_QUESTIONS.find((q) => q.key === "companions");
                    if (!companionsStep || companionsStep.type !== "companions") return null;
                    return (
                      <ChipGroup options={companionsStep.childAgeOptions} selected={editTempMulti} onChange={setEditTempMulti} />
                    );
                  })()}

                {editingFieldKey === "timing" &&
                  (() => {
                    const editStep = RESTAURANTS_CAFES_QUESTIONS.find((q) => q.key === "timing");
                    if (!editStep || editStep.type !== "date") return null;
                    return (
                      <div className="flex flex-col gap-3">
                        <AnswerOptions options={editStep.options} selected={editTempValue} onSelect={setEditTempValue} />
                        {editTempValue === editStep.otherDateTriggerValue && (
                          <Field label="בחר תאריך">
                            <input
                              type="date"
                              value={editTempText}
                              onChange={(e) => setEditTempText(e.target.value)}
                              className="w-full rounded-pill border border-ink-secondary/25 bg-bg px-4 py-3 text-sm text-ink focus:outline-none focus:ring-2 focus:ring-accent/40"
                            />
                          </Field>
                        )}
                      </div>
                    );
                  })()}

                {(editingFieldKey === "distanceBand" || editingFieldKey === "budgetBand") &&
                  (() => {
                    const editStep = RESTAURANTS_CAFES_QUESTIONS.find((q) => q.key === editingFieldKey);
                    if (!editStep || editStep.type !== "slider") return null;
                    return (
                      <Slider
                        steps={editStep.steps}
                        value={editTempSlider ?? (form[editingFieldKey] as string)}
                        onChange={setEditTempSlider}
                      />
                    );
                  })()}

                {editingFieldKey === "cuisine" &&
                  (() => {
                    const editStep = RESTAURANTS_CAFES_QUESTIONS.find((q) => q.key === "cuisine");
                    if (!editStep || editStep.type !== "multi-emoji") return null;
                    return <ChipGroup options={editStep.options} selected={editTempMulti} onChange={setEditTempMulti} />;
                  })()}

                {editingFieldKey === "freeText" && (
                  <textarea
                    value={editTempText}
                    onChange={(e) => setEditTempText(e.target.value)}
                    rows={3}
                    className="w-full rounded-card border border-ink-secondary/25 bg-bg p-4 text-sm text-ink focus:outline-none focus:ring-2 focus:ring-accent/40"
                  />
                )}

                <div className="mt-3 flex justify-center gap-2">
                  <button
                    type="button"
                    onClick={closeEdit}
                    className="flex-1 rounded-pill border border-ink-secondary/25 bg-white py-2 text-sm font-medium text-ink-secondary shadow-md"
                  >
                    ביטול
                  </button>
                  <button
                    type="button"
                    onClick={confirmEdit}
                    className="flex-1 rounded-pill py-2 text-sm font-semibold text-white shadow-md"
                    style={{ background: "linear-gradient(135deg, var(--color-primary-start), var(--color-primary-end))" }}
                  >
                    עדכן
                  </button>
                </div>
              </div>
            );
          }

          return m.role === "assistant" ? (
            <ChatBubble key={m.id}>{m.text}</ChatBubble>
          ) : m.role === "icon" ? (
            <div key={m.id} className="flex items-end justify-end gap-2">
              <TripTypeBadge label={m.text} />
              <UserAvatar avatarUrl={profile?.avatar_url ?? null} name={profile?.full_name ?? null} />
            </div>
          ) : (
            <div key={m.id} className="flex items-end justify-end gap-2">
              <UserBubble onClick={m.fieldKey ? () => openEdit(m) : undefined}>{m.text}</UserBubble>
              <UserAvatar avatarUrl={profile?.avatar_url ?? null} name={profile?.full_name ?? null} />
            </div>
          );
        })}

        {!editingFieldKey && typing && <TypingIndicator />}

        {!editingFieldKey && !typing && !submitting && !awaitingTripChoice && (
          <div className="mt-1">
            {step.type === "companions" && !awaitingChildAges && (
              <div className="flex flex-col gap-3">
                <AnswerOptions options={step.options} selected={tempCompanion} onSelect={handleCompanionsSelect} />
                <button
                  type="button"
                  onClick={togglePet}
                  className="flex w-fit items-center gap-1.5 rounded-pill border px-3.5 py-2 text-[13px] font-medium transition active:scale-95"
                  style={{
                    borderColor: "#9C6B30",
                    background: tempHasPet ? "#9C6B30" : "#ffffff",
                    color: tempHasPet ? "#ffffff" : "#9C6B30",
                  }}
                >
                  🐶 עם בעל חיים
                </button>
              </div>
            )}
            {step.type === "companions" && awaitingChildAges && (
              <ChipGroup options={step.childAgeOptions} selected={tempMulti} onChange={setTempMulti} />
            )}

            {step.type === "date" && !awaitingOtherDate && (
              <AnswerOptions options={step.options} onSelect={handleDateSelect} />
            )}
            {step.type === "date" && awaitingOtherDate && (
              <Field label="בחר תאריך">
                <input
                  type="date"
                  value={tempText}
                  onChange={(e) => setTempText(e.target.value)}
                  className="w-full rounded-pill border border-ink-secondary/25 bg-bg px-4 py-3 text-sm text-ink focus:outline-none focus:ring-2 focus:ring-accent/40"
                />
              </Field>
            )}

            {step.type === "slider" && (
              <div className="rounded-card bg-white p-4 shadow-md">
                <Slider
                  steps={step.steps}
                  value={tempSlider ?? (form[step.key as keyof RestaurantAnswers] as string)}
                  onChange={(value) => setTempSlider(value)}
                />
              </div>
            )}

            {step.type === "multi-emoji" && (
              <ChipGroup options={step.options} selected={tempMulti} onChange={setTempMulti} />
            )}

            {step.type === "text" && (
              <textarea
                value={tempText}
                onChange={(e) => setTempText(e.target.value)}
                placeholder={step.placeholder}
                rows={3}
                className="w-full rounded-card border border-ink-secondary/25 bg-bg p-4 text-sm text-ink placeholder:text-ink-secondary focus:outline-none focus:ring-2 focus:ring-accent/40"
              />
            )}
          </div>
        )}

        {!editingFieldKey && awaitingTripChoice && (
          <>
            <TripChoiceCards onChoose={handleTripChoice} disabled={busyChoice} />
            {submitting && <ChatBubble>רגע, מוצאים לכם את המקום...</ChatBubble>}
          </>
        )}

        {locationError && <p className="text-center text-sm text-danger">{locationError}</p>}

        {!editingFieldKey && !awaitingTripChoice && footerAction && (
          <div className="flex justify-center pt-2">
            <button
              type="button"
              onClick={footerAction.onClick}
              disabled={footerAction.disabled}
              className="w-full rounded-pill py-2 text-sm font-semibold text-white shadow-md disabled:opacity-50"
              style={{ background: "linear-gradient(135deg, var(--color-primary-start), var(--color-primary-end))" }}
            >
              {footerAction.label}
            </button>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      <MainBottomNav active="ai" />
    </Screen>
  );
}

function getCurrentPosition(): Promise<{ lat: number; lng: number }> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("הדפדפן שלך לא תומך באיתור מיקום"));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (position) => resolve({ lat: position.coords.latitude, lng: position.coords.longitude }),
      () => reject(new Error("יש לאשר גישה למיקום כדי למצוא מקום קרוב אליכם")),
      { enableHighAccuracy: false, timeout: 10000 }
    );
  });
}
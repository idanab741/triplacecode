﻿"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Chip, ImageOptionCard, ImageOptionRow, Screen, Switch } from "@/components/ui";
import { SimpleAppHeader } from "@/screens/layout/SimpleAppHeader";
import { MainBottomNav } from "@/components/MainBottomNav";
import { useAuth } from "@/hooks/useAuth";
import { isMainOnboardingComplete, isProfileComplete } from "@/services/profile/profileService";
import {
  isPreferencesComplete,
  savePreferences,
  completePreferences,
} from "@/services/preferences/preferencesService";
import {
  STEPS,
  EMPTY_PREFERENCES_STATE,
  type PreferencesFormState,
  type MultiFieldKey,
} from "./steps";
import { DIETARY_RESTRICTIONS } from "@/locales/he/preferences";

/** שלבים שמוצגים כצ'יפים עם עיגול תמונה קטן (במקום אריח תמונה גדול) -
 *  מתאים לרשימות ארוכות שבהן עדיפה סריקה מהירה. */
const ROW_STYLE_STEP_KEYS: MultiFieldKey[] = ["culinary_styles", "accommodation_types"];

function PreferencesPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const returnTo = searchParams.get("returnTo");

  const {
    user,
    loading,
    profile,
    profileLoading,
    preferences,
    preferencesLoading,
    refreshPreferences,
  } = useAuth();

  const [stepIndex, setStepIndex] = useState(0);
  const [form, setForm] = useState<PreferencesFormState>(EMPTY_PREFERENCES_STATE);
  const [initialized, setInitialized] = useState(false);
  const [saving, setSaving] = useState(false);

  if (!preferencesLoading && !initialized) {
    setInitialized(true);
    setForm({
      culinary_styles: preferences?.culinary_styles ?? [],
      dietary_restrictions: preferences?.dietary_restrictions ?? [],
      kosher: preferences?.kosher ?? false,
      accessibility: preferences?.accessibility ?? false,
      transportation: preferences?.transportation ?? [],
      interests: preferences?.interests ?? [],
      accommodation_types: preferences?.accommodation_types ?? [],
      vacation_preferences: preferences?.vacation_preferences ?? [],
    });
  }

  useEffect(() => {
    if (!loading && !profileLoading && user && !isProfileComplete(profile)) {
      router.replace("/profile-setup");
    }
  }, [loading, profileLoading, user, profile, router]);

  useEffect(() => {
    if (loading || profileLoading || !user || !isProfileComplete(profile)) return;
    if (!isMainOnboardingComplete(profile)) {
      router.replace("/onboarding");
    }
  }, [loading, profileLoading, user, profile, router]);

  useEffect(() => {
    if (!preferencesLoading && isPreferencesComplete(preferences) && !returnTo) {
      if (!isMainOnboardingComplete(profile)) return;
      router.replace("/home");
    }
  }, [preferencesLoading, preferences, returnTo, router, profile]);

  const step = STEPS[stepIndex];
  const isLastStep = stepIndex === STEPS.length - 1;

  function toggleChip(key: MultiFieldKey, value: string) {
    setForm((f) => {
      const list = f[key];
      const next = list.includes(value)
        ? list.filter((v) => v !== value)
        : [...list, value];
      return { ...f, [key]: next };
    });
  }

  async function advance(updatedForm: PreferencesFormState, markComplete: boolean) {
    if (!user) return;
    setForm(updatedForm);
    setSaving(true);

    if (markComplete) {
      await completePreferences(user.id, updatedForm);
    } else {
      let fieldsToSave: Partial<PreferencesFormState>;
      if (step.key === "culinary_styles") {
        fieldsToSave = { culinary_styles: updatedForm.culinary_styles, dietary_restrictions: updatedForm.dietary_restrictions, kosher: updatedForm.kosher };
      } else if (step.key === "transportation") {
        fieldsToSave = { transportation: updatedForm.transportation, accessibility: updatedForm.accessibility };
      } else {
        fieldsToSave = { [step.key]: updatedForm[step.key] };
      }
      await savePreferences(user.id, fieldsToSave);
    }

    setSaving(false);

    if (markComplete) {
      await refreshPreferences();
      router.push(returnTo || "/home");
    } else {
      setStepIndex((i) => i + 1);
    }
  }

  function handleNext() {
    advance(form, isLastStep);
  }

  // כפתור "הבא" נחסם אם זה שלב בחירה מרובה ולא נבחר אף פריט - למי שלא
  // רוצה לבחור כלום יש את כפתור "דלג" הייעודי מתחתיו.
  const nextDisabled = saving || (step.type === "multi" && form[step.key].length === 0);

  function handleSkip() {
    const cleared: PreferencesFormState = {
      ...form,
      [step.key]: step.type === "multi" ? [] : false,
      ...(step.key === "culinary_styles" ? { dietary_restrictions: [], kosher: false } : {}),
      ...(step.key === "transportation" ? { accessibility: false } : {}),
    };
    advance(cleared, isLastStep);
  }

  function handleBack() {
    setStepIndex((i) => Math.max(0, i - 1));
  }

  if (loading || profileLoading || preferencesLoading || !initialized) {
    return (
      <Screen withBottomNavSpacing={false}>
        <p className="pt-10 text-center text-ink-secondary">טוען...</p>
      </Screen>
    );
  }

  return (
    <Screen withBottomNavSpacing className="!bg-bg !px-0 !pt-0">
      <SimpleAppHeader
        onBack={() => (stepIndex > 0 ? handleBack() : router.push(returnTo || "/home"))}
        disabled={saving}
      />

      <div className="mx-auto flex max-w-xl flex-col gap-6 px-5 pb-4 pt-5">
        <div className="h-1.5 w-full overflow-hidden rounded-pill bg-bg-secondary">
          <div
            className="h-full rounded-pill bg-[linear-gradient(135deg,var(--color-primary-start),var(--color-primary-end))] transition-all"
            style={{ width: `${((stepIndex + 1) / STEPS.length) * 100}%` }}
          />
        </div>

        <header className="text-center">
          <h1 className="text-2xl font-bold text-ink">{step.title}</h1>
          <p className="mt-1.5 text-xs font-medium text-ink-secondary">
            שלב {stepIndex + 1} מתוך {STEPS.length}
          </p>
        </header>

        {step.type === "multi" && ROW_STYLE_STEP_KEYS.includes(step.key) && (
          <div className="flex flex-wrap justify-center gap-2">
            {step.options.map((option) => (
              <ImageOptionRow
                key={option.value}
                selected={form[step.key].includes(option.value)}
                onClick={() => toggleChip(step.key, option.value)}
                label={option.label}
                imageSrc={option.imageSrc}
              />
            ))}
          </div>
        )}

        {step.type === "multi" && step.key === "vacation_preferences" && (
          <div className="flex flex-wrap justify-center gap-2">
            {step.options.map((option) => (
              <ImageOptionRow
                key={option.value}
                selected={form[step.key].includes(option.value)}
                onClick={() => toggleChip(step.key, option.value)}
                label={option.label}
                imageSrc={option.imageSrc}
                imageWidth={64}
                imageHeight={44}
              />
            ))}
          </div>
        )}

        {step.type === "multi" &&
          !ROW_STYLE_STEP_KEYS.includes(step.key) &&
          step.key !== "vacation_preferences" &&
          step.options.some((o) => o.imageSrc) && (
          <div className="grid content-start grid-cols-3 gap-1.5">
            {step.options.map((option) => (
         <ImageOptionCard
                key={option.value}
                selected={form[step.key].includes(option.value)}
                onClick={() => toggleChip(step.key, option.value)}
                label={option.label}
                imageSrc={option.imageSrc}
              />
            ))}
          </div>
        )}

{step.type === "multi" && !ROW_STYLE_STEP_KEYS.includes(step.key) && step.key !== "vacation_preferences" && !step.options.some((o) => o.imageSrc) && (
          <div className="flex flex-wrap justify-center gap-2">
            {step.options.map((option) => (
              <Chip
                key={option.value}
                selected={form[step.key].includes(option.value)}
                onClick={() => toggleChip(step.key, option.value)}
              >
                {option.emoji ? `${option.emoji} ${option.label}` : option.label}
              </Chip>
            ))}
          </div>
        )}

        {step.type === "toggle" && (
          <Switch
            checked={form[step.key]}
            onChange={(checked) => setForm((f) => ({ ...f, [step.key]: checked }))}
            label={step.title}
          />
        )}

        {step.key === "culinary_styles" && (
          <div className="border-t border-ink-secondary/10 pt-3">
            <p className="mb-2.5 text-center text-sm font-semibold text-ink">העדפות מיוחדות</p>
            <div className="flex flex-wrap justify-center gap-2">
              {DIETARY_RESTRICTIONS.map((option) => {
                const isKosher = option.value === "kosher";
                const selected = isKosher ? form.kosher : form.dietary_restrictions.includes(option.value);
                return (
                  <Chip
                    key={option.value}
                    selected={selected}
                    onClick={() =>
                      isKosher
                        ? setForm((f) => ({ ...f, kosher: !f.kosher }))
                        : toggleChip("dietary_restrictions", option.value)
                    }
                  >
                    {option.label}
                  </Chip>
                );
              })}
            </div>
          </div>
        )}

        {step.key === "transportation" && (
          <div className="border-t border-ink-secondary/10 pt-3">
            <p className="mb-2.5 text-center text-sm font-semibold text-ink">העדפות נוספות</p>
            <div className="flex flex-wrap justify-center gap-2">
              <Chip
                selected={form.accessibility}
                onClick={() => setForm((f) => ({ ...f, accessibility: !f.accessibility }))}
              >
                נגישות
              </Chip>
            </div>
          </div>
        )}

        <button
          type="button"
          onClick={handleNext}
          disabled={nextDisabled}
          className="rounded-pill py-2 text-sm font-semibold text-white shadow-md disabled:opacity-50"
          style={{ background: "linear-gradient(135deg, var(--color-primary-start), var(--color-primary-end))" }}
        >
          {isLastStep ? "סיום" : "הבא"}
        </button>

        <button
          type="button"
          onClick={handleSkip}
          disabled={saving}
          className="text-center text-sm text-ink-secondary"
        >
          דלג
        </button>
      </div>

      <MainBottomNav active="profile" />
    </Screen>
  );
}

export default function PreferencesPage() {
  return (
    <Suspense
      fallback={
        <Screen withBottomNavSpacing={false}>
          <p className="pt-10 text-center text-ink-secondary">טוען...</p>
        </Screen>
      }
    >
      <PreferencesPageContent />
    </Suspense>
  );
}
